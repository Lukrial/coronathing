import processing.core.PApplet;
import processing.data.Table;

public class Graph extends Main {
    PApplet p;
    Table USDeaths;

    int dayPixels = 8;
    float deadPixels = (float) 0.02;
    int row;

    Graph(PApplet p, Table USDeaths, int row){
        this.p = p;
        this.USDeaths = USDeaths;
        this.row = row;
    }

    void graphDraw(){
        for (int i = 1; i < 111; i++) {
            p.rect(i * 10, p.height - 50 - USDeaths.getInt(i,2), 10, (USDeaths.getInt(i,2)));
            p.stroke(100,100,100);
            if (i == 111) {
                i = 1;
            }
        }
        for (int w = 1; w < 113; w = w + 10) {
            p.text(w, w * 10+20, 690);
        }
    }
}


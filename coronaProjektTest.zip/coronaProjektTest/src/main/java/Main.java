import processing.core.PApplet;
import processing.data.Table;

public class Main extends PApplet {
    Graph USDeaths;
    PApplet p;
    Table t;
    int row = mouseX;

    public static void main(String[] args) {
        PApplet.main("Main");
    }

    @Override
    public void settings() {
        super.settings();
        size(800, 500);
    }

    @Override
    public void setup() {
        super.setup();
        t = loadTable("us.csv","header");
        USDeaths = new Graph(this,t,row);
    }

    public void draw() {
        background(183, 166, 173);
        textSize(15);
        text("Accumulated deaths due to COVID-19, 01/21/2020 - 05/11/2020",50,50);
        translate(100,450);
        scale((float)0.5,(float)0.005);
        USDeaths.graphDraw();
    }
}
